# EJERCICIO 2.1
- :root línea 3
- :hover línea 234
- :focus línea 239
- :link línea 248
- :visited línea 252
- ::selection línea 256
- :after línea 75
- :before línea 155

